<?php
$telegram_id = "7753194662";
$id_bot      = "7861678411:AAFLg7IwjKBLUKTaOPhH701frm0fiZnX9zY";
?>